<?php
session_start();
if (isset($_SESSION['admin'])) {
    header('location: home.php');
}
?>
<?php include 'includes/header.php'; ?>

<body class="hold-transition login-page" style="background-color: #F1E9D2; font-family: 'Times New Roman', Times, serif;">
<div class="login-box">
    <div class="login-logo" style="color: #ffffff; background-color: #a69f8b; padding: 20px; border-radius: 10px 10px 0 0;">
        <b>Online Voting System</b>
    </div>
  
    <div class="login-box-body" style="background-color: #ffffff; padding: 20px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);">
        <p class="login-box-msg" style="color: #333; font-size: 16px;">Sign in to start your admin session</p>

        <form action="login.php" method="POST">
            <div class="form-group has-feedback">
                <input type="text" class="form-control" name="username" placeholder="Username" required>
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" class="form-control" name="password" placeholder="Password" required>
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="row">
                <div class="col-xs-4">
                    <button type="submit" class="btn btn-primary btn-block btn-curve" style="background-color: #4682B4; color: #ffffff; font-size: 14px;" name="login">
                        <i class="fa fa-sign-in"></i> Sign In
                    </button>
                </div>
            </div>
        </form>
    </div>

    <?php
    if (isset($_SESSION['error'])) {
        echo "
        <div class='callout callout-danger text-center mt20' style='background-color: #ffccd1; color: #a94442; margin-top: 20px; border-radius: 5px; padding: 10px;'>
            <p>" . $_SESSION['error'] . "</p> 
        </div>
        ";
        unset($_SESSION['error']);
    }
    ?>
</div>
  
<?php include 'includes/scripts.php'; ?>
</body>
</html>
